package kaptainwutax.seedcrackerX.scanner;

import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public final class PersistenceChecks {
    private static void check(boolean value, String label) {
        if (!value) throw new AssertionError(label);
    }
    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("seed-scanner-checks");
        Path worldA = dir.resolve("a.json"), worldB = dir.resolve("b.json");
        AtomicStore.State state = new AtomicStore.State();
        var evidence = new AtomicStore.Evidence();
        evidence.type = "surface_dungeon"; evidence.x = -5432; evidence.y = 42;
        evidence.floor = new int[]{0, 1, 2}; evidence.biome = "plains";
        state.evidence.add(evidence); state.scanned.add("minecraft:overworld:-5:12");
        state.pillars = List.of(76,79,82,85,88,91,94,97,100,103);
        state.worldSeed = Long.MIN_VALUE + 123;
        AtomicStore.write(worldA, state);
        var restored = AtomicStore.read(worldA);
        check(restored.worldSeed.equals(state.worldSeed), "64-bit seed precision");
        check(restored.evidence.getFirst().x == -5432, "negative coordinates");
        check(Arrays.equals(restored.evidence.getFirst().floor, evidence.floor), "dungeon floor restoration");
        check(restored.pillars.equals(state.pillars), "end pillars restoration");
        check(restored.scanned.equals(state.scanned), "scan history survives restart");
        AtomicStore.write(worldB, new AtomicStore.State());
        check(AtomicStore.read(worldA).evidence.size() == 1 && AtomicStore.read(worldB).evidence.isEmpty(), "world isolation");
        AtomicStore.write(worldA, new AtomicStore.State());
        check(AtomicStore.read(worldA).scanned.isEmpty() && AtomicStore.read(worldA).worldSeed == null, "reset is persistent");
        check(!Files.exists(dir.resolve("a.json.tmp")), "atomic write committed");
        Files.writeString(worldA, "{broken");
        try { AtomicStore.read(worldA); throw new AssertionError("corrupt file accepted"); }
        catch (java.io.IOException expected) { check(Files.readString(worldA).equals("{broken"), "corrupt original preserved"); }
        Files.writeString(worldA, "{\"schema\":99}");
        try { AtomicStore.read(worldA); throw new AssertionError("unknown schema accepted"); }
        catch (java.io.IOException expected) { }
        ScanProgress scan = new ScanProgress();
        check(scan.submit("overworld:1:1") && !scan.submit("overworld:1:1"), "pending deduplication");
        check(scan.percent() == 0, "pending scan not complete");
        scan.finish("overworld:1:1", true);
        check(scan.percent() == 100 && !scan.submit("overworld:1:1"), "completed deduplication");
        ScanProgress rejoin = new ScanProgress(); rejoin.restore(scan.snapshot());
        check(!rejoin.submit("overworld:1:1"), "rejoin deduplication");
        check(rejoin.submit("end:1:1"), "dimension separation");
        rejoin.finish("end:1:1", false);
        check(rejoin.failures() == 1 && rejoin.submit("end:1:1"), "failed chunks remain retryable");
        rejoin.rescan(); check(rejoin.submit("overworld:1:1"), "manual rescan");
        var pool = Executors.newFixedThreadPool(4);
        ScanProgress parallel = new ScanProgress();
        for (int i=0; i<1000; i++) {
            String key = "chunk:"+i;
            pool.submit(() -> { check(parallel.submit(key), "parallel submit"); parallel.finish(key,true); });
        }
        pool.shutdown(); check(pool.awaitTermination(10, TimeUnit.SECONDS), "parallel completion");
        check(parallel.completed()==1000 && parallel.pending()==0, "concurrent counters");
        CalculationProgress calculation = new CalculationProgress(); calculation.begin("test", 100);
        calculation.done.set(25); check(calculation.percent()==25, "calculation work counters");
        calculation.done.set(200); check(calculation.percent()==100, "bounded progress");
        System.out.println("PASS: persistence, reset, corruption, world/dimension isolation, scan deduplication, concurrent counters, calculation progress");
    }
}
