package kaptainwutax.seedcrackerX.scanner;

import com.seedfinding.mccore.rand.seed.WorldSeed;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcfeature.structure.DesertPyramid;
import kaptainwutax.seedcrackerX.Features;
import kaptainwutax.seedcrackerX.cracker.DataAddedEvent;
import kaptainwutax.seedcrackerX.cracker.decorator.Dungeon;
import kaptainwutax.seedcrackerX.cracker.decorator.DeepDungeon;
import kaptainwutax.seedcrackerX.cracker.storage.DataStorage;
import java.util.*;

public final class SeedEngineChecks {
    private static void check(boolean value, String label) { if (!value) throw new AssertionError(label); }
    public static void main(String[] args) throws Exception {
        for (long known : new long[]{1234567890123456789L, -98765432101234567L}) {
            long structureSeed = known & ((1L << 48)-1);
            long hash = WorldSeed.toHash(known);
            Set<Long> result = new HashSet<>();
            for (long upper=0; upper<1L<<16; upper++) {
                long candidate=(upper<<48)|structureSeed;
                if (WorldSeed.toHash(candidate)==hash) result.add(candidate);
            }
            check(result.equals(new HashSet<>(WorldSeed.fromHash(structureSeed,hash))), "hash search matches upstream");
            check(result.equals(Set.of(known)), "known world seed recovered");
        }
        Features.DUNGEON = new Dungeon(MCVersion.latest());
        Features.DEEP_DUNGEON = new DeepDungeon(MCVersion.latest());
        Features.STRUCTURE_TYPES.clear();
        var temple = new DesertPyramid(MCVersion.latest());
        Features.STRUCTURE_TYPES.add(temple);
        var modern = Features.DUNGEON.at(35, 42, -77, null, null, Biomes.PLAINS, null);
        var encoded = EvidenceCodec.encode(modern);
        check(encoded.y==42 && encoded.floor==null, "modern dungeon has no floor/height metadata");
        DataStorage storage = new DataStorage();
        EvidenceCodec.restore(encoded,storage);
        var deep = Features.DEEP_DUNGEON.at(-34,-32,123,Biomes.PLAINS);
        EvidenceCodec.restore(EvidenceCodec.encode(deep),storage);
        EvidenceCodec.restore(EvidenceCodec.encode(temple.at(-12,45)),storage);
        check(storage.evidenceCount()==3, "all supported evidence types restored");
        check(!storage.addBaseData(modern,DataAddedEvent.POKE_BIOMES), "restored evidence deduplicates");
        storage.close();
        check(!storage.addBaseData(temple.at(99,99),DataAddedEvent.POKE_LIFTING), "closed world rejects stale scanner task");
        check(storage.evidenceCount()==3, "late task cannot change closed journal");
        System.out.println("PASS: real seed hash recovery, modern dungeon serialization, deep dungeon/structure restoration, stale task rejection");
    }
}
