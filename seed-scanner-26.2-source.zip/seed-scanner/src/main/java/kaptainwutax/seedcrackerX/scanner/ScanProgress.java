package kaptainwutax.seedcrackerX.scanner;

import java.util.HashSet;
import java.util.Set;

public final class ScanProgress {
    private final Set<String> completed = new HashSet<>();
    private final Set<String> pending = new HashSet<>();
    private long failures;
    public synchronized boolean submit(String chunk) {
        return !completed.contains(chunk) && pending.add(chunk);
    }
    public synchronized void finish(String chunk, boolean success) {
        if (!pending.remove(chunk)) return;
        if (success) completed.add(chunk); else failures++;
    }
    public synchronized void restore(Set<String> chunks) { completed.addAll(chunks); }
    public synchronized Set<String> snapshot() { return new HashSet<>(completed); }
    public synchronized long completed() { return completed.size(); }
    public synchronized long pending() { return pending.size(); }
    public synchronized long failures() { return failures; }
    public synchronized double percent() {
        int total = completed.size() + pending.size();
        return total == 0 ? 0 : completed.size() * 100.0 / total;
    }
    public synchronized void rescan() { completed.clear(); }
}
