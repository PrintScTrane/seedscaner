package kaptainwutax.seedcrackerX.scanner;

import kaptainwutax.seedcrackerX.SeedCracker;
import kaptainwutax.seedcrackerX.config.Config;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import java.util.Locale;

public final class ScannerHud {
    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("seedcrackerx", "scanner_progress"), (graphics, delta) -> {
            Minecraft client = Minecraft.getInstance();
            if (client.level == null || !Config.get().scannerHud) return;
            var storage = SeedCracker.get().getDataStorage();
            var progress = storage.calculation;
            Long seed = storage.getTimeMachine().foundWorldSeed;
            double target = storage.hasPillars() ? 32 : 40;
            double bits = storage.hasPillars() ? storage.hudBaseBits() : storage.hudLiftingBits();
            double collected = Math.min(100, bits / target * 100);
            if (!storage.hasPillars()) collected = Math.min(collected, storage.hudBaseBits() / 32 * 100);
            String scan = String.format(Locale.ROOT, "청크 스캔 %.1f%% · %d완료 / %d대기",
                    storage.scan.percent(), storage.scan.completed(), storage.scan.pending());
            String info = String.format(Locale.ROOT, "정보 수집 %.1f%% · %.1f/%.0f비트 · 기록 %d개",
                    collected, bits, target, storage.evidenceCount());
            String calculation = progress.total == 0 ? "연산: " + progress.stage
                    : String.format(Locale.ROOT, "연산 %.1f%% · %s", progress.percent(), progress.stage);
            String footer = seed == null ? "구조물을 더 탐색하면 자동 연산합니다" : "월드 시드: " + seed;
            if (storage.saveBlocked) footer = "저장 파일 오류 · /seedscan reset";
            if (seed == null && storage.scan.failures() > 0) footer = "스캔 오류 " + storage.scan.failures() + "회 · /seedscan rescan";
            String[] lines = { "Seed Scanner 26.2" + (Config.get().active ? "" : " · 일시 중지"), scan, info, calculation, footer };
            int width = 230;
            for (String line : lines) width = Math.max(width, client.font.width(line) + 16);
            graphics.fill(6, 6, 6 + width, 99, 0xB018202C);
            for (int i = 0; i < lines.length; i++) {
                graphics.text(client.font, lines[i], 12, 12 + i * 16, i == 0 ? 0xFF80E0FF : 0xFFFFFFFF, true);
                if (i > 0 && i < 4) {
                    double value = i == 1 ? storage.scan.percent() : i == 2 ? collected : progress.percent();
                    graphics.fill(12, 22 + i * 16, width, 24 + i * 16, 0xFF364658);
                    graphics.fill(12, 22 + i * 16, 12 + (int)((width - 12) * value / 100), 24 + i * 16, 0xFF60C8DD);
                }
            }
        });
    }
}
