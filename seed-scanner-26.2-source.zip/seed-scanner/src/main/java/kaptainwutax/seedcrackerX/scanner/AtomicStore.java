package kaptainwutax.seedcrackerX.scanner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Plain data only: never serialize Minecraft worlds or feature object graphs. */
public final class AtomicStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static class State {
        public int schema = 1;
        public String minecraft = "26.2";
        public List<Evidence> evidence = new ArrayList<>();
        public List<Integer> pillars;
        public Set<String> scanned = new HashSet<>();
        public Long worldSeed;
    }
    public static class Evidence {
        public String type;
        public int x, y, z, bottom, top, sizeX, sizeY, sizeZ;
        public int[] floor;
        public String biome;
    }
    public static State read(Path path) throws IOException {
        if (!Files.exists(path)) return new State();
        try {
            State state = GSON.fromJson(Files.readString(path, StandardCharsets.UTF_8), State.class);
            if (state == null || state.schema != 1 || !"26.2".equals(state.minecraft)
                    || state.evidence == null || state.scanned == null) {
                throw new IOException("Unsupported or invalid scan file: " + path);
            }
            return state;
        } catch (RuntimeException e) {
            throw new IOException("Invalid scan JSON: " + path, e);
        }
    }
    public static void write(Path path, State state) throws IOException {
        Files.createDirectories(path.getParent());
        Path temporary = path.resolveSibling(path.getFileName() + ".tmp");
        Files.writeString(temporary, GSON.toJson(state), StandardCharsets.UTF_8);
        try {
            Files.move(temporary, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
