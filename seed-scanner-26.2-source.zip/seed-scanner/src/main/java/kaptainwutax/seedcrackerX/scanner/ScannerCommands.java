package kaptainwutax.seedcrackerX.scanner;

import com.mojang.brigadier.CommandDispatcher;
import kaptainwutax.seedcrackerX.SeedCracker;
import kaptainwutax.seedcrackerX.config.Config;
import kaptainwutax.seedcrackerX.finder.ReloadFinders;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.literal;

public final class ScannerCommands {
    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(literal("seedscan")
                .executes(c -> status(c.getSource()))
                .then(literal("status").executes(c -> status(c.getSource())))
                .then(literal("reset").executes(c -> {
                    SessionPersistence.reset();
                    c.getSource().sendFeedback(Component.literal("현재 월드의 스캔 기록과 시드 결과를 초기화했습니다."));
                    new ReloadFinders().reload();
                    return 1;
                }))
                .then(literal("rescan").executes(c -> {
                    new ReloadFinders().reload();
                    c.getSource().sendFeedback(Component.literal("받아온 주변 청크를 다시 스캔합니다. 발견 기록은 유지됩니다."));
                    return 1;
                }))
                .then(literal("hud").then(literal("on").executes(c -> hud(true)))
                        .then(literal("off").executes(c -> hud(false))))
                .then(literal("pause").executes(c -> {
                    Config.get().active = false; Config.save(); return 1;
                }))
                .then(literal("resume").executes(c -> {
                    Config.get().active = true; Config.save(); new ReloadFinders().reload(); return 1;
                })));
    }
    private static int hud(boolean enabled) { Config.get().scannerHud = enabled; Config.save(); return 1; }
    private static int status(FabricClientCommandSource source) {
        var s = SeedCracker.get().getDataStorage();
        source.sendFeedback(Component.literal(String.format(java.util.Locale.ROOT,
                "스캔 %.1f%% (%d완료 / %d대기), 정보 %.1f/40비트, 일반 %.1f/32비트, 연산 %.1f%%: %s",
                s.scan.percent(), s.scan.completed(), s.scan.pending(), s.hudLiftingBits(), s.hudBaseBits(),
                s.calculation.percent(), s.calculation.stage)));
        if (s.getTimeMachine().foundWorldSeed != null)
            source.sendFeedback(Component.literal("월드 시드: " + s.getTimeMachine().foundWorldSeed));
        return 1;
    }
}
