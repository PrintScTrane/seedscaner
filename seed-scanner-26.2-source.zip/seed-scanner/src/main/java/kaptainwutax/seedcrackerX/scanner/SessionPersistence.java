package kaptainwutax.seedcrackerX.scanner;

import kaptainwutax.seedcrackerX.SeedCracker;
import kaptainwutax.seedcrackerX.cracker.DataAddedEvent;
import kaptainwutax.seedcrackerX.cracker.HashedSeedData;
import kaptainwutax.seedcrackerX.cracker.PillarData;
import kaptainwutax.seedcrackerX.cracker.storage.DataStorage;
import kaptainwutax.seedcrackerX.finder.FinderQueue;
import kaptainwutax.seedcrackerX.util.Log;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.storage.LevelResource;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;

public final class SessionPersistence {
    public static void join(long hash) {
        Minecraft client = Minecraft.getInstance();
        String world;
        if (client.getSingleplayerServer() != null) {
            world = "local:" + client.getSingleplayerServer().getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize();
        } else if (client.getCurrentServer() != null) {
            world = "server:" + client.getCurrentServer().ip.toLowerCase(java.util.Locale.ROOT);
        } else {
            world = "server:" + client.getConnection().getConnection().getRemoteAddress();
        }
        String key;
        try {
            key = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                    .digest((world + ":" + hash).getBytes(StandardCharsets.UTF_8)));
        } catch (java.security.NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
        Path path = FabricLoader.getInstance().getConfigDir().resolve("seed-scanner/worlds").resolve(key + ".json");
        DataStorage previous = SeedCracker.get().getDataStorage();
        if (path.equals(previous.savePath)) return;
        leave();
        DataStorage storage = SeedCracker.get().getDataStorage();
        storage.savePath = path;
        storage.addHashedSeedData(new HashedSeedData(hash), DataAddedEvent.POKE_BIOMES);
        try {
            AtomicStore.State state = AtomicStore.read(path);
            for (var record : state.evidence) EvidenceCodec.restore(record, storage);
            if (state.pillars != null) storage.addPillarData(new PillarData(state.pillars), DataAddedEvent.POKE_PILLARS);
            storage.scan.restore(state.scanned);
            if (state.worldSeed != null) {
                storage.getTimeMachine().worldSeeds.add(state.worldSeed);
                storage.getTimeMachine().foundWorldSeed = state.worldSeed;
                storage.calculation.stage = "시드 발견";
                Log.printSeed("tmachine.foundWorldSeed", state.worldSeed);
            }
            if (!state.evidence.isEmpty()) Log.warn("스캔 기록 " + state.evidence.size() + "개를 자동 복원했습니다.");
        } catch (Exception e) {
            storage.saveBlocked = true;
            SeedCracker.LOGGER.error("Could not restore scan state; preserving original file", e);
            Log.error("스캔 파일을 읽지 못했습니다. 원본을 보존했습니다. /seedscan reset으로 초기화할 수 있습니다.");
        }
    }
    public static void leave() {
        DataStorage storage = SeedCracker.get().getDataStorage();
        storage.close();
        storage.saveState();
        SeedCracker.get().replaceStorage(new DataStorage());
        FinderQueue.get().clear();
    }
    public static void reset() {
        DataStorage old = SeedCracker.get().getDataStorage();
        old.close();
        DataStorage fresh = new DataStorage();
        fresh.savePath = old.savePath;
        fresh.hashedSeedData = old.hashedSeedData;
        SeedCracker.get().replaceStorage(fresh);
        FinderQueue.get().clear();
        fresh.saveState();
    }
}
