package kaptainwutax.seedcrackerX.scanner;

import java.util.concurrent.atomic.AtomicLong;

/** Progress belongs to one DataStorage generation, so cancelled workers cannot update a new world. */
public final class CalculationProgress {
    public volatile String stage = "정보 수집 대기";
    public volatile long total;
    public volatile boolean running;
    public final AtomicLong done = new AtomicLong();
    public void begin(String stage, long total) {
        this.stage = stage;
        this.total = total;
        done.set(0);
        running = true;
    }
    public double percent() { return total == 0 ? 0 : Math.min(100, done.get() * 100.0 / total); }
}
