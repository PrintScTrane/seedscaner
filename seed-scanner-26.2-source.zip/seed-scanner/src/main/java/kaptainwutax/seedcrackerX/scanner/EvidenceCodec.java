package kaptainwutax.seedcrackerX.scanner;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcfeature.Feature;
import kaptainwutax.seedcrackerX.Features;
import kaptainwutax.seedcrackerX.cracker.DataAddedEvent;
import kaptainwutax.seedcrackerX.cracker.decorator.Dungeon;
import kaptainwutax.seedcrackerX.cracker.decorator.DeepDungeon;
import kaptainwutax.seedcrackerX.cracker.storage.DataStorage;
import kaptainwutax.seedcrackerX.util.HeightContext;
import net.minecraft.core.Vec3i;

public final class EvidenceCodec {
    public static AtomicStore.Evidence encode(Feature.Data<?> data) {
        AtomicStore.Evidence r = new AtomicStore.Evidence();
        r.type = data.feature.getName(); r.x = data.chunkX; r.z = data.chunkZ;
        if (data instanceof Dungeon.Data d) {
            r.type = "surface_dungeon"; r.x = d.blockX; r.y = d.blockY; r.z = d.blockZ;
            r.bottom = d.heightContext == null ? -64 : d.heightContext.getBottomY();
            r.top = d.heightContext == null ? 320 : d.heightContext.getTopY();
            r.floor = d.floorCalls == null ? null : d.floorCalls.clone();
            if (d.size != null) { r.sizeX = d.size.getX(); r.sizeY = d.size.getY(); r.sizeZ = d.size.getZ(); }
            r.biome = d.biome.getName();
        } else if (data instanceof DeepDungeon.Data d) {
            r.type = "deep_dungeon"; r.x = (d.chunkX << 4) + d.offsetX;
            r.y = d.blockY; r.z = (d.chunkZ << 4) + d.offsetZ; r.biome = d.biome.getName();
        } else if (Features.STRUCTURE_TYPES.stream().noneMatch(f -> f == data.feature)) {
            return null;
        }
        return r;
    }
    private static Biome biome(String name) {
        for (var field : Biomes.class.getFields()) {
            try {
                if (field.get(null) instanceof Biome b && b.getName().equals(name)) return b;
            } catch (ReflectiveOperationException ignored) { }
        }
        throw new IllegalArgumentException("Unknown saved biome " + name);
    }
    public static void restore(AtomicStore.Evidence r, DataStorage storage) {
        if ("surface_dungeon".equals(r.type)) {
            var data = Features.DUNGEON.at(r.x, r.y, r.z, new Vec3i(r.sizeX, r.sizeY, r.sizeZ),
                    r.floor, biome(r.biome), new HeightContext(r.bottom, r.top));
            storage.addBaseData(data, data::onDataAdded);
        } else if ("deep_dungeon".equals(r.type)) {
            storage.addBaseData(Features.DEEP_DUNGEON.at(r.x, r.y, r.z, biome(r.biome)), DataAddedEvent.POKE_BIOMES);
        } else {
            var feature = Features.STRUCTURE_TYPES.stream().filter(f -> f.getName().equals(r.type)).findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("Unknown saved feature " + r.type));
            storage.addBaseData(feature.at(r.x, r.z), DataAddedEvent.POKE_LIFTING);
        }
    }
}
