package kaptainwutax.seedcrackerX;

import com.mojang.logging.LogUtils;
import kaptainwutax.seedcrackerX.api.SeedCrackerAPI;
import kaptainwutax.seedcrackerX.config.Config;
import kaptainwutax.seedcrackerX.cracker.storage.DataStorage;
import kaptainwutax.seedcrackerX.finder.FinderQueue;
import kaptainwutax.seedcrackerX.init.ClientCommands;
import kaptainwutax.seedcrackerX.scanner.ScannerHud;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;

import java.util.ArrayList;

public class SeedCracker implements ModInitializer {
    public static final Logger LOGGER = LogUtils.getLogger();
    public static final ArrayList<SeedCrackerAPI> entrypoints = new ArrayList<>();
    private static SeedCracker INSTANCE;
    private volatile DataStorage dataStorage = new DataStorage();
    private static final ThreadLocal<DataStorage> WORKER_STORAGE = new ThreadLocal<>();
    public static void withStorage(DataStorage storage, Runnable work) {
        WORKER_STORAGE.set(storage);
        try { if (!storage.closed) work.run(); } finally { WORKER_STORAGE.remove(); }
    }
    public void replaceStorage(DataStorage storage) { this.dataStorage = storage; }

    public static SeedCracker get() {
        return INSTANCE;
    }

    @Override
    public void onInitialize() {
        INSTANCE = this;
        Config.load();
        Features.init(Config.get().getVersion());
        FabricLoader.getInstance().getEntrypointContainers("seedcrackerx", SeedCrackerAPI.class).forEach(entrypoint ->
                entrypoints.add(entrypoint.getEntrypoint()));

        FinderQueue.registerEvents();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> ClientCommands.registerCommands(dispatcher));

        ScannerHud.register();
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.level != null) getDataStorage().autosaveTick();
        });
    }

    public DataStorage getDataStorage() {
        return WORKER_STORAGE.get() == null ? this.dataStorage : WORKER_STORAGE.get();
    }

    public void reset() {
        kaptainwutax.seedcrackerX.scanner.SessionPersistence.reset();
    }
}
