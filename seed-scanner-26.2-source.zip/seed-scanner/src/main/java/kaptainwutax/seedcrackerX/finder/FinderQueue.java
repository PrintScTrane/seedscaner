package kaptainwutax.seedcrackerX.finder;

import com.mojang.blaze3d.vertex.PoseStack;
import kaptainwutax.seedcrackerX.config.Config;
import kaptainwutax.seedcrackerX.render.Cuboid;
import net.fabricmc.fabric.api.client.rendering.v1.RenderStateDataKey;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class FinderQueue {

    private final static FinderQueue INSTANCE = new FinderQueue();
    private static final Logger log = LoggerFactory.getLogger(FinderQueue.class);
    public static ExecutorService SERVICE = Executors.newFixedThreadPool(5);

    private static final RenderStateDataKey<Set<Cuboid>> CUBOID_SET_KEY = RenderStateDataKey.create(() -> "SeedCrackerX cuboid set");

    public FinderControl finderControl = new FinderControl();

    private FinderQueue() {
        this.clear();
    }

    public static void registerEvents() {
        LevelRenderEvents.END_EXTRACTION.register(levelExtractionContext -> FinderQueue.get().extractCuboids(levelExtractionContext.levelState(), levelExtractionContext.camera()));
        LevelRenderEvents.END_MAIN.register(levelRenderContext -> FinderQueue.get().renderCuboids(levelRenderContext.submitNodeCollector(), levelRenderContext.poseStack(), levelRenderContext.levelState()));
    }

    public static FinderQueue get() {
        return INSTANCE;
    }

    public void onChunkData(Level world, ChunkPos chunkPos) {
        if (!Config.get().active) return;

        if (!world.hasChunk(chunkPos.x(), chunkPos.z())) return;
        var storage = kaptainwutax.seedcrackerX.SeedCracker.get().getDataStorage();
        if (storage.closed) return;
        String key = world.dimension().identifier() + ":" + chunkPos.x() + ":" + chunkPos.z();
        if (!storage.scan.submit(key)) return;
        var types = getActiveFinderTypes();
        var control = this.finderControl;
        SERVICE.submit(() -> kaptainwutax.seedcrackerX.SeedCracker.withStorage(storage, () -> {
            boolean success = true;
            try {
                for (var type : types) {
                    if (storage.closed) { success = false; break; }
                    try {
                        List<Finder> finders = type.finderBuilder.build(world, chunkPos);
                        for (Finder finder : finders) {
                            if (storage.closed) { success = false; break; }
                            if (finder.isValidDimension(world.dimensionType())) {
                                finder.findInChunk();
                                if (!storage.closed) control.addFinder(type, finder);
                            }
                        }
                    } catch (Exception e) {
                        success = false;
                        log.error("Chunk scan failed: " + key + " / " + type, e);
                    }
                }
            } finally { storage.scan.finish(key, success); }
        }));
    }

    private void extractCuboids(LevelRenderState state, Camera camera) {
        if (Config.get().render == Config.RenderType.OFF) {
            ((net.fabricmc.fabric.api.client.rendering.v1.FabricRenderState) state).setData(CUBOID_SET_KEY, Collections.emptySet());
            return;
        }
        Set<Cuboid> cuboids = new HashSet<>();
        this.finderControl.getActiveFinders().forEach(finder -> {
            if (finder.shouldRender()) {
                finder.cuboids.forEach(cuboid -> cuboids.add(cuboid.offset(camera)));
            }
        });
        ((net.fabricmc.fabric.api.client.rendering.v1.FabricRenderState) state).setData(CUBOID_SET_KEY, cuboids);
    }

    public void renderCuboids(SubmitNodeCollector submitter, PoseStack poseStack, LevelRenderState state) {
        Set<Cuboid> cuboids = ((net.fabricmc.fabric.api.client.rendering.v1.FabricRenderState) state).getData(CUBOID_SET_KEY);
        if (cuboids == null) {
            return;
        }
        cuboids.forEach(cuboid -> cuboid.render(poseStack, submitter));
    }

    public List<Finder.Type> getActiveFinderTypes() {
        return Arrays.stream(Finder.Type.values())
                .filter(type -> type.enabled.get())
                .collect(Collectors.toList());
    }

    public void clear() {
        this.finderControl = new FinderControl();
    }
}
