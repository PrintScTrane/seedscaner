package kaptainwutax.seedcrackerX.cracker.storage;

import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.Feature;
import com.seedfinding.mcfeature.decorator.DesertWell;
import com.seedfinding.mcfeature.decorator.EndGateway;
import com.seedfinding.mcfeature.structure.BuriedTreasure;
import com.seedfinding.mcfeature.structure.OldStructure;
import com.seedfinding.mcfeature.structure.PillagerOutpost;
import com.seedfinding.mcfeature.structure.Shipwreck;
import com.seedfinding.mcfeature.structure.Structure;
import com.seedfinding.mcfeature.structure.TriangularStructure;
import com.seedfinding.mcfeature.structure.UniformStructure;
import kaptainwutax.seedcrackerX.config.ConfigScreen;
import kaptainwutax.seedcrackerX.cracker.BiomeData;
import kaptainwutax.seedcrackerX.cracker.DataAddedEvent;
import kaptainwutax.seedcrackerX.cracker.HashedSeedData;
import kaptainwutax.seedcrackerX.cracker.PillarData;
import kaptainwutax.seedcrackerX.cracker.decorator.Decorator;
import kaptainwutax.seedcrackerX.cracker.decorator.DeepDungeon;
import kaptainwutax.seedcrackerX.cracker.decorator.Dungeon;
import kaptainwutax.seedcrackerX.cracker.decorator.EmeraldOre;
import kaptainwutax.seedcrackerX.cracker.decorator.WarpedFungus;
import kaptainwutax.seedcrackerX.finder.BlockUpdateQueue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

import java.util.Comparator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public class DataStorage {
    private static final Consumer<DataStorage> AUTO_CRACK = DataAddedEvent.POKE_LIFTING::onDataAdded;
    public volatile boolean closed;
    public java.nio.file.Path savePath;
    public boolean saveBlocked;
    public final kaptainwutax.seedcrackerX.scanner.ScanProgress scan = new kaptainwutax.seedcrackerX.scanner.ScanProgress();
    public final kaptainwutax.seedcrackerX.scanner.CalculationProgress calculation = new kaptainwutax.seedcrackerX.scanner.CalculationProgress();
    private final java.util.Map<String, kaptainwutax.seedcrackerX.scanner.AtomicStore.Evidence> journal = new java.util.LinkedHashMap<>();
    private int saveTicks;
    private volatile double cachedBaseBits, cachedLiftingBits;
    public double hudBaseBits() { return cachedBaseBits; }
    public double hudLiftingBits() { return cachedLiftingBits; }
    public boolean hasPillars() { return pillarData != null; }
    public synchronized int evidenceCount() { return journal.size(); }
    public synchronized void close() {
        closed = true;
        timeMachine.shouldTerminate = true;
        scheduledData.clear();
    }
    public void autosaveTick() {
        if (++saveTicks >= 100) { saveTicks = 0; saveState(); }
    }
    public synchronized void saveState() {
        if (savePath == null || saveBlocked) return;
        var state = new kaptainwutax.seedcrackerX.scanner.AtomicStore.State();
        state.evidence.addAll(journal.values());
        state.pillars = pillarData == null ? null : pillarData.savedHeights();
        state.scanned = scan.snapshot();
        state.worldSeed = timeMachine.foundWorldSeed;
        try { kaptainwutax.seedcrackerX.scanner.AtomicStore.write(savePath, state); }
        catch (java.io.IOException e) {
            kaptainwutax.seedcrackerX.SeedCracker.LOGGER.error("Could not save scan state", e);
            kaptainwutax.seedcrackerX.util.Log.error("스캔 기록 저장 실패: 디스크 공간과 권한을 확인해 주세요.");
        }
    }

    public static final Comparator<Entry<Feature.Data<?>>> SEED_DATA_COMPARATOR = (s1, s2) -> {
        boolean isStructure1 = s1.data.feature instanceof Structure;
        boolean isStructure2 = s2.data.feature instanceof Structure;

        //Structures always come before decorators.
        if (isStructure1 != isStructure2) {
            return isStructure2 ? 1 : -1;
        }

        if (s1.equals(s2)) {
            return 0;
        }

        int order = Double.compare(getBits(s2.data.feature, false), getBits(s1.data.feature, false));
        if (order != 0) return order;
        order = s1.data.feature.getClass().getName().compareTo(s2.data.feature.getClass().getName());
        if (order != 0) return order;
        order = Integer.compare(s1.data.chunkX, s2.data.chunkX);
        return order != 0 ? order : Integer.compare(s1.data.chunkZ, s2.data.chunkZ);
    };
    public ScheduledSet<Entry<Feature.Data<?>>> baseSeedData = new ScheduledSet<>(SEED_DATA_COMPARATOR);
    public HashedSeedData hashedSeedData = null;
    public BlockUpdateQueue blockUpdateQueue = new BlockUpdateQueue();
    public boolean openGui = false;
    protected TimeMachine timeMachine = new TimeMachine(this);
    protected Set<Consumer<DataStorage>> scheduledData = ConcurrentHashMap.newKeySet();
    protected PillarData pillarData = null;
    protected ScheduledSet<Entry<BiomeData>> biomeSeedData = new ScheduledSet<>(null);

    public static double getBits(Feature<?, ?> feature, boolean decorators18) {
        if (feature instanceof UniformStructure<?> s) {
            return Math.log(s.getOffset() * s.getOffset()) / Math.log(2);
        } else if (feature instanceof TriangularStructure<?> s) {
            return Math.log(s.getPeak() * s.getPeak()) / Math.log(2);
        }
        if (!decorators18 && feature instanceof Decorator && feature.getVersion().isNewerThan(MCVersion.v1_17_1))
            return 0;
        if (feature instanceof BuriedTreasure) return Math.log(100) / Math.log(2);
        if (feature instanceof DesertWell) return Math.log(1000 * 16 * 16) / Math.log(2);
        if (feature instanceof Dungeon) return Math.log(256 * 16 * 16 * 0.125D) / Math.log(2);
        if (feature instanceof DeepDungeon) return Math.log(58 * 16 * 16 * 0.25D) / Math.log(2);
        if (feature instanceof EmeraldOre) return Math.log(28 * 16 * 16 * 0.5D) / Math.log(2);
        if (feature instanceof EndGateway) return Math.log(700 * 16 * 16 * 7) / Math.log(2);
        if (feature instanceof WarpedFungus) return 0;

        throw new UnsupportedOperationException("go do implement bits count for " + feature.getName() + " you fool");
    }

    public void tick() {
        if (closed) return;
        if (openGui) {
            ConfigScreen configscreen = new ConfigScreen();
            Screen screen = configscreen.getConfigScreenByCloth(Minecraft.getInstance().gui.screen());
            Minecraft.getInstance().gui.setScreen(screen);
            openGui = false;
        }
        if (!this.timeMachine.isRunning) {
            this.baseSeedData.dump();
            this.biomeSeedData.dump();
            blockUpdateQueue.tick();

            cachedBaseBits = getBaseBits(); cachedLiftingBits = getLiftingBits();
            TimeMachine machine = this.timeMachine;
            machine.isRunning = true;
            java.util.Set<Consumer<DataStorage>> events = this.scheduledData;
            TimeMachine.SERVICE.submit(() -> {
                try {
                    events.removeIf(c -> {
                        if (!closed && !machine.shouldTerminate) c.accept(this);
                        return true;
                    });
                } catch (Exception e) {
                    kaptainwutax.seedcrackerX.SeedCracker.LOGGER.error("Seed calculation failed", e);
                    calculation.stage = "연산 오류 · 로그를 확인해 주세요";
                    calculation.running = false;
                } finally {
                    machine.isRunning = false;
                }
            });
        }
    }

    public synchronized boolean addPillarData(PillarData data, DataAddedEvent event) {
        if (closed) return false;
        boolean isAdded = this.pillarData == null;

        if (isAdded && data != null) {
            this.pillarData = data;
            this.schedule(event::onDataAdded);
        }

        return isAdded;
    }

    public synchronized boolean addBaseData(Feature.Data<?> data, DataAddedEvent event) {
        if (closed) return false;
        Entry<Feature.Data<?>> e = new Entry<>(data, event);

        if (this.baseSeedData.contains(e)) {
            return false;
        }

        this.baseSeedData.scheduleAdd(e);
        if (!(data.feature instanceof PillagerOutpost)) cachedBaseBits += getBits(data.feature, false);
        if (data.feature instanceof OldStructure structure) {
            cachedLiftingBits += Math.log(structure.getOffset() * structure.getOffset()) / Math.log(2);
        } else if (data.feature instanceof Shipwreck shipwreck) {
            cachedLiftingBits += Math.log(shipwreck.getOffset() * shipwreck.getOffset()) / Math.log(2);
        }
        var record = kaptainwutax.seedcrackerX.scanner.EvidenceCodec.encode(data);
        if (record != null) journal.put(record.type + ":" + record.x + ":" + record.y + ":" + record.z, record);
        this.schedule(event::onDataAdded);
        if (cachedLiftingBits >= 40 && cachedBaseBits >= getWantedBits()) this.schedule(AUTO_CRACK);
        return true;
    }

    public synchronized boolean addBiomeData(BiomeData data, DataAddedEvent event) {
        if (closed) return false;
        Entry<BiomeData> e = new Entry<>(data, event);

        if (this.biomeSeedData.contains(e)) {
            return false;
        }

        this.biomeSeedData.scheduleAdd(e);
        this.schedule(event::onDataAdded);
        return true;
    }

    public synchronized boolean addHashedSeedData(HashedSeedData data, DataAddedEvent event) {
        if (closed) return false;
        if (this.hashedSeedData == null || this.hashedSeedData.getHashedSeed() != data.getHashedSeed()) {
            this.hashedSeedData = data;
            this.schedule(event::onDataAdded);
            return true;
        }

        return false;
    }

    public void schedule(Consumer<DataStorage> consumer) {
        if (!closed) this.scheduledData.add(consumer);
    }

    public TimeMachine getTimeMachine() {
        return this.timeMachine;
    }

    public double getBaseBits() {
        double bits = 0.0D;

        for (Entry<Feature.Data<?>> e : this.baseSeedData) {
            if (!(e.data.feature instanceof PillagerOutpost)) {
                bits += getBits(e.data.feature, false);
            }
        }
        return bits;
    }

    public double getLiftingBits() {
        double bits = 0.0D;

        for (Entry<Feature.Data<?>> e : this.baseSeedData) {
            if (e.data.feature instanceof OldStructure structure) {
                bits += Math.log(structure.getOffset() * structure.getOffset()) / Math.log(2);
            } else if (e.data.feature instanceof Shipwreck shipwreck) {
                bits += Math.log(shipwreck.getOffset() * shipwreck.getOffset()) / Math.log(2);
            }
        }
        return bits;
    }

    public double getDecoratorBits() {
        double bits = 0.0D;

        for (Entry<Feature.Data<?>> e : this.baseSeedData) {
            if (e.data.feature instanceof Decorator decorator) {
                bits += getBits(decorator, true);
            }
        }
        return bits;
    }

    public double getWantedBits() {
        return 32.0D;
    }

    public boolean notEnoughBiomeData() {
        return this.biomeSeedData.size() < 7;
    }

    public void clear() {
        this.scheduledData = ConcurrentHashMap.newKeySet();
        this.pillarData = null;
        this.baseSeedData = new ScheduledSet<>(SEED_DATA_COMPARATOR);
        this.biomeSeedData = new ScheduledSet<>(null);
        //this.hashedSeedData = null;
        this.timeMachine.shouldTerminate = true;
        this.timeMachine = new TimeMachine(this);
        this.blockUpdateQueue = new BlockUpdateQueue();
    }

    public static class Entry<T> {
        public final T data;
        public final DataAddedEvent event;

        public Entry(T data, DataAddedEvent event) {
            this.data = data;
            this.event = event;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Entry<?> entry)) return false;

            if (this.data instanceof Feature.Data<?> d1 && entry.data instanceof Feature.Data<?> d2) {
                return d1.feature == d2.feature && d1.chunkX == d2.chunkX && d1.chunkZ == d2.chunkZ;
            } else if (this.data instanceof BiomeData && entry.data instanceof BiomeData) {
                return this.data.equals(entry.data);
            }

            return false;
        }

        @Override
        public int hashCode() {
            if (this.data instanceof Feature.Data<?>) {
                return ((Feature.Data<?>) this.data).chunkX * 31 + ((Feature.Data<?>) this.data).chunkZ;
            } else if (this.data instanceof BiomeData) {
                return this.data.hashCode();
            }

            return super.hashCode();
        }
    }

}
